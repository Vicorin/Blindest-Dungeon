# Translation files for the Darkest Dungeon accessibility mod
#
# Almost everything the mod speaks comes from the game's own localization tables and follows
# the game's language setting automatically. The files in this folder cover the REST: the
# mod's own feedback lines ("No exit that way.", "Turn skipped.") that the game has no words
# for. English is built into the mod; a file here overrides it for one language.
#
# HOW IT WORKS
# - Name a file after the game's INTERNAL language name plus .txt: german.txt, french.txt,
#   spanish.txt, italian.txt, czech.txt, polish.txt, russian.txt, ... (the same names the
#   game itself uses; pick a language in the game's Options to see the mod log the name in
#   focus-runtime.log as: axlang: applied language "..." ).
# - These files deploy to <game>\_windows\win64\ddaccess-lang\ next to ddaccess.dll
#   (poc\build.ps1 copies them on every build).
# - The mod reads the game's language once at startup and keeps it for the session. A
#   language change in the game's Options therefore applies at the NEXT game start -- the
#   same moment the game's own text switches (it also only loads its language at startup),
#   so the mod and the game always speak the same language.
#
# FILE FORMAT
# - Plain UTF-8 text. One entry per line:  IDENTIFIER=translated text
# - Lines starting with # or ; are comments. Empty lines are ignored.
# - The full list of identifiers and their English defaults is poc\src\core\axstrings.inc
#   (each AXS(IDENTIFIER, "English") line). Any identifier you leave out stays English --
#   a partial translation is fine.
# - Keep printf placeholders (%d, %s) exactly as in the English text, in the same order.
#   An entry whose placeholders do not match is skipped (logged in focus-runtime.log), so a
#   typo cannot break the mod -- but do check the log after testing a new file.
# - Translate the WHOLE sentence naturally; word order may differ from English freely.
