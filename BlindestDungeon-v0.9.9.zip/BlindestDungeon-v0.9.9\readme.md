## About the Mod
Blindest Dungeon adds screen-reader support and enhanced keyboard navigation to Darkest Dungeon, making it fully accessible to blind and low-vision players.

## Current Status & Limitations

Currently, the entire base game is accessible, as well as much of the DLC. It is in public beta so that I can begin to gather player feedback while I polish the mod and support the last of the DLC items.

* Base game: fully accessible, some interface items may change slightly to create a smoother experience.
* DLC Characters and Districts: Fully accessible.
* The Color of  Madness: Mostly accessible. I have completed the first quest using the mod and have most of the endless mode features working, but have not yet tested the full endless mode.
* Crimson Court: Fully Accessible
* Fire's Edge: Fully Accessible
(* Butcher's Circus: Not accessible yet. The main menu for the circus is read, but it is the most unfinished area of the mod and is a work in progress.
(* Operating System: Windows. The mod has switched to the Prism speech library, but more work is needed to achieve full compatability on Mac and Linux.
* Localization: English, German, French, Spanish. Some of the speech output had to be written by hand and has to be translated. Text that was able to be pulled straight from the game is localized, but the mod text is still a work in progress. Feedback from players who speak languages other than English is greatly appreciated. Support for all 13 languages available in the game is planned.

## Installation and Updates

Download and run "Blindest Dungeon Installer.exe" (found in the mod release). It will automatically locate your game path and install the files. It can also be used to uninstall or update the mod with the click of a button.

To manually install or update, copy and paste all files inside the mod directory next to the darkest.exe shortcut: (Darkest Dungeon > Windows > Win64). To uninstall, simply delete them.

The mod will alert you of new updates automatically when you launch the game. To turn this off, open the mod settings with F10 while in the game and press Enter on "Check for updates on launch"; the change applies from the next launch.

### Creating A Windows Defender Exception

Due to the nature of the game's custom C++ engine and a lack of official script modding support, this mod relies on DLL injection and live memory reading to detect and translate game text into speech, which is often automatically flagged by Windows Defender and other antivirus software. The warning is not due to any malicious code in the mod, simply the method it uses. To prevent this and get the game to run, you may need to follow these steps to add the game folder as a Windows Defender exception.

* Open Windows Security. You can find it in the start menu if you're not sure where to look.
* Press enter on "Virus and Threat Protection".
* Press enter on the link to "Manage Settings", found in the "threat settings" section.
* Tab to "Exclusions" and press enter on the link to "Add or Remove exclusions".
* Press Enter on "Add Exclusion" and select the folder where you have the game installed.

## Getting Started
### Starting a Campaign
Launch the game via the access shortcut included with the mod. The mod will take a minute to load, but then you should hear "accessibility mod loaded". After the opening cinematic, there is a small text preamble that seeks to prepare you for the difficulty of the game. Press the comma key (,) to re-read this message or any other popup found throughout the game.

The main menu is very simple, you can navigate with the arrow keys, enter to select an item, or escape to open the pause/options menu.

Select campaign. At the top you'll find the Butcher's Circus, which is a PvP mode that can be downloaded for free. Below that, you have your 9 save slots.

Press enter on an empty slot to start a new game. If you have any DLC or workshop mods installed, you will have the opportunity to select what content you want loaded into that save. Press the ok button to continue to the difficulty selection. All difficulty modes provide a challenge, but Radiant is easiest and recommended for your first time.

After selecting a difficulty, name your estate. It starts with the word Darkest" auto-filled, and has a max of 10 characters. You'll hear the updated entry as you type or delete text. Press enter to save.

Pressing enter on a filled save slot will load that save, such as the one you just created. You can delete a save using the delete key.

You can view and enable DLC installed on an existing save by pressing SHIFT+ENTER. You can enable DLC mid-run, but you cannot disable them.

After the initial cutscene, you will start in a short tutorial mission with 2 characters.

## Dungeon View
Most of the game will take place in side-scrolling dungeons. Your characters will be lined up on the left side of the screen, while objects, doors, and enemies will appear on the right. Note that position 1 is at the front of your party, which faces to the right.

* Pressing Q/E will cycle selected party member left/right.
* Press C to view the selected hero's character sheet.
* Press R to see what's in the room, where you can look at your party members without selecting them, interact with objects, and view/target enemies.
*  left/right arrows move through what's in the room. up/down to move between the action bar and quest tracker.
* Ctrl+up/down arrow will read through tooltip information about each creature or object in the room. This is how you will view many other tooltips found throughout the game.
* D moves your party forward, and A moves them back. They take more stress when walking back.
* Hold shift and tap A/D to move back/forwards to the next tile. This prevents announcements being cut off while moving and ensures you don't accidentally walk past any objects or doors.
* Press W to interact with curios, disarm traps, or open doors.
* Press L to check the current light level and its effects.
* Press T to light a torch.
* G jumps to the quest tracker, where you can view your current goal, abandon the quest, retreat from battle, or finish the quest when it's complete.
* Press tilde (`) to jump to the action bar from anywhere, where you can view the selected hero, their skills, and rearrange the party.
* Press Tab to cycle to the map/inventory. You can also press M or I to open one directly.
* press period (.) to open the event log to review anything that happens to your heroes in or out of combat.

### Map/Hallway Navigation
After pressing tab or the M key to jump to the map, you'll be able to scout ahead and move between rooms of the dungeon. Each room of the dungeon is arranged on a grid, with connecting hallways in between. After clearing each room, you'll need to select your next destination from the map.

* Arrow keys to move between rooms on the map.
* Ctrl+arrows to walk tile-by-tile down the connecting hallways.
* Enter to move to an adjacent room.
* Home to return to the party's location on the map.

After you select your destination on the map, you will then need to walk through the hallway to reach the door on the other side. This is best accomplished using the tile navigation (shift+d to move forward and shift+a to move back) as holding the movement keys has a tendency to cut off announcements, making it easy to miss what's happening.

Note: Your party will always be moving to the right towards the destination you selected on the map. Walking backwards/to the left will return you to the room you just left.

## Combat
During combat, a group of enemies will appear on the right. You can use the arrow keys to move through them inside the dungeon view, and CTRL+up arrow will read tooltips with information about them.

You'll hear a short drumming sound and hear the name of one of your heroes, letting you know it's their turn. You can select skills from the action bar, or use 1-4 to select them if you know their position. 5 will also issue a move order.

Once a skill is selected, you'll need to pick a target, you'll hear your chance to hit, estimated damage, and chance to crit as you move between enemies. Pressing enter will attack or heal the selected target, depending on the skill.

Every skill and effect has its own sound effect, which you'll learn over time, but the mod will also speak what's happening live and write it to the event log. You can cut off the battle announcements with the CTRRL key.

## Inventory & Loot
The inventory has 16 slots, (2 rows of 8). Everything you pick up will go here. You can use an item or equip a trinket by pressing enter on it and selecting a target. Pressing delete will trash an item, clearing room for more valuable loot.

After winning a battle or opening treasure, you'll be greeted with a loot screen, where you can take individual items by pressing enter on them, or take all by pressing spacebar. You can tab to the inventory if you need to trash items to make room.

## Interacting with Objects

Press W to interact with a curio, open the door to a room, or disarm a trap. Inside a room, objects can sit out of your party's reach; Shift+D (or Shift+A) walks the party until the next object that way is in reach and says so, and then W will take it. When interacting with a curio or trap, any positive or negative effects will apply to the selected hero, and some heroes (such as the antiquarian) may impact the loot you find. In some cases, you'll have the opportunity to use an item. Simply select that option from the list, and then select the item you'd like to use; you'll hear "works here" next to its name if you can use that item.

## Finishing a Quest

When you complete your goal for the dungeon, you will be prompted with the option to continue adventuring or return to the Hamlet. If you continue adventuring, you can return at any time by pressing the button in the quest bar, found above the dungeon view or by pressing G. This is also where you can abandon a quest early or retreat from combat if you don't think your heroes will survive.

Whether you were victorious, fled the dungeon, or died terribly, you'll come to the rewards and XP screens before returning to the Hamlet. The first screen displays all of the loot you found in the dungeon. Most items are sold off for gold, except for trinkets and heirlooms which are added to your inventory.

After the loot rewards is the XP summary. Each hero is displayed with their own column, use left/right arrows to navigate between heroes and up/down to move through their summary. Often, heroes will develop new quirks, which may be positive or negative. Press enter to reveal these and you can read their full effects at the bottom of each hero's column. Pressing enter a second time will return you to the hamlet.

## Hamlet View

The Hamlet is where you'll spend most of your time between raids, managing your hero roster and resources. You'l l typically return to the hamlet with the activity log open, detailing everything that's happened for that week in one column, and your overall goals in the other.

* Period (.) to open/close the activity log.
* Comma (,) to re-read a popup, such as a tutorial message or town event.
* Tab moves between the hamlet map and your hero roster.
* R opens the resource panel, where you can see your gold and heirlooms, which are another kind of currency you'll need for upgrading buildings. You can also trade 1 type of heirloom for another, using the trade button on that panel.
* I opens the trinket inventory where you can equip trinkets to heroes or sell the ones you don't want.
* E to embark, opening the expedition planning screen so you can set off on your next quest.

### Building Shortcuts

From within the list of Hamlet locations or an open building screen, you can use the following keys to open a location directly.

* A: Abbey
 B: Blacksmith
* C: Stagecoach
* D: Districts
* L: Guild
* M: Ancestor's Memoirs
* S: Sanitarium
* T: Tavern
* V: Survivalist
* W: Nomad Wagon
* Y: Graveyard
* Z: Butcher's Circus

### Building Screens

Most buildings are organized into rows and columns. You'll learn what each building does as you unlock them, but the controls for each will be the same.

* Arrow keys to navigate
* Enter to select
* escape to close
* U for building upgrades

### Trading Heirlooms

The heirloom exchange is a simple shop interface with two columns. On the left are your heirlooms. Select one to add it to your offer. On the right side, you'll see what you can afford with your current offer. 

### Trinket Inventory

The trinket inventory is a 7x5 grid, with a button to unequip all of your trinkets for every hero in the roster and some sorting options.

* Pressing enter on a trinket here will take you to select a character, and then to select a trinket slot on their character sheet.
* Shift+Enter will sell a trinket. Press enter to confirm.

## Embarking

Press E to embark when you're ready to leave town. Embarking has two screens: the expedition map where you select a quest and your party lineup, and a provisions screen, where you spend gold for supplies to carry with you into the dungeon. Pressing E will advance you to each of these screens until you are in the dungeon. Escape will take you back.

### Selecting a Quest

Quests are organized in columns, by location. You can use the up/down arrows to move between the different quests available at that location. Use the tooltip buffer (CTRL+up arrow to read the quest goal, description, and rewards. Enter will select the quest.

Press Tab to reach the party lineup.

### Organizing your party

Pressing tab from the quest list will put you in the party lineup. It is 4 horizontal slots, with #1 being on the far right to reflect how they will be arranged in the dungeon. Press enter on a slot to open the roster. Pressing enter on any hero in the roster will assign them to that slot. Pressing C will open their character sheet.

Pressing the spacebar on any hero in the party will allow you to rearrange them. move to another slot and press space again to drop them. You can cancel with the scape key.

### Provisioning

Press E after selecting a quest and party to move to the provisioning shop. There are two columns, one for goods in the shop on the left, and your inventory on the right. Press enter to buy an item from the shop or sell it from your inventory. Shift+enter will buy/sell the whole stack.

Press E when you're ready to start the quest.

## Camping

On medium or longer quests, your party will automatically bring firewood in their inventory to camp at least once. The game will not prompt you to camp, but when your party needs to recover, you can use the firewood from your inventory to camp. You must be in a room to do this, you can't camp in the hallways.

Camping has two phases. First, you'll select how much food you want to eat, which is a simple list of options. The second phase, the skills phase, is where your heroes can use camping skills to heal, reduce their stress, and buff themselves for what lies ahead.

During the skills phase, you will hear how many respite points you have in the readout for the dungeon view. Each camping skill will cost a number of these points. Once you have 6 or less remaining, you'll see a button to rest on the action bar, which will finish camping and return you to the normal dungeon.

Use Q/E to change the selected hero and find their camping skills in the action bar under the dungeon view. You can check their tooltips to learn more about what each skill does.

## Traps

If your party successfully scouts a trap, they will stop short on that tile to avoid setting it off. In the dungeon view, you will be able to see each hero's chance to disarm the trap. Select the character you want to interact with the trap and press W.

If you fail to scout a trap, it will not be visible on the map and your party will walk straight into it. It targets the currently-selected hero, and their chance to dodge is determined by their trap resistance (found on their character sheet).

## Secret Rooms

Some dungeons have secret rooms, which you will be unable to see unless you critically succeed at scouting. Once spotted, you will be able to see them on the map, hear them annouced when you move onto their tile, and be able to enter them by pressing W, like any other door.

Inside, there is usually some treasure, and then you will need to exit via the map. Open the map, sselect a nearby room as your destination, and press enter to return to the corridor.

## Mod Settings
Press F10 from anywhere in the game to open the mod settings where you can see all of the controls added by the mod and remap them to your preference. Simply press enter on the command you want to modify, then press the key you want to become the new shortcut. To cancel, simply press the same key that was already assigned or exit the mod settings without saving.

Under Announcements, the first row of the menu, you'll find the mod's speech preferences. Press Enter on a row to step it to its next value, or Left and Right to step back and forward. "Subtitles" reads the game's own subtitles aloud: On or Off. "Barks" controls whether the speech balloons over your heroes are read: On, Only in dungeons, Only in town, or Off. Both changes take effect at once and are remembered.

Under Speech, the second row, you choose what the mod speaks through. "Speech handler" is Auto by default: the mod's speech library, Prism, uses your running screen reader and falls back to Windows speech when none is running. Set it to Prism to pick a specific Prism backend in the next row, or to SAPI to always use Windows SAPI voices regardless of your screen reader. "SAPI configuration" opens the voice, rate and volume used when SAPI is speaking; the voice list is available while SAPI is the active output, and rate and volume go from 0 to 100 percent in steps of ten. Every change applies immediately and is remembered.

The mod settings also features a debugg logging mode, which will write a log of live game data to a text file, stored in the same folder as the mod install. It is off by default, but you can turn it on to record bugs and send me the log to fix bugs faster.

## Help & Feedback
Join [My Discord](https://discord.gg/avQTPGy2FA) to get help, report bugs, or offer your suggestions.

## Support my Work

Donations are not expected. I do this because I like games and am passionate about making them more accessible. That said, it does cost money to produce these mods, so if you like my work and want to help out, you can [support me on ko-fi](https://ko-fi.com/axdelvegames)

## Third-Party Software

Blindest Dungeon speaks through PRISM (prism.dll), a screen-reader abstraction library by Ethin Probst. PRISM is licensed under the Mozilla Public License, version 2.0; its source code and the full license text are available at https://github.com/ethindp/prism. The copy shipped with this mod is the unmodified v0.18.2 release.

PRISM itself includes the following open-source components, whose copyright and license notices are reproduced here as their licenses require:

* simdutf, licensed under the Apache License, version 2.0 (https://www.apache.org/licenses/LICENSE-2.0).
* Moderncom, Copyright 2020 HHD Software Ltd., author Alexander Bessonov, licensed under the MIT License.
* {fmt}, Copyright (c) 2012 - present, Victor Zverovich and {fmt} contributors, licensed under the MIT License.
* concurrentqueue, Copyright (c) 2013-2016, Cameron Desrochers, all rights reserved, licensed under the Simplified BSD License.
* dr_wav by David Reid, released into the public domain.
* NVDA controller client RPC definitions, originally LGPL-2.1, relicensed to PRISM under the MPL-2.0 with the NVDA project's permission.

MIT License: Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions: The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software. THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

Simplified BSD License: Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met: 1. Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer. 2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution. THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

Disclaimer: Blindest Dungeon is not an official Red Hook Studios product or product modification, and Red Hook Studios Inc. is not responsible in any way for changes or damages that may result from using the mod. Furthermore, “Darkest Dungeon” and the Darkest Dungeon logo are trademarks of Red Hook Studios Inc. All content in the game is Copyright Red Hook Studios Inc. All rights reserved.
